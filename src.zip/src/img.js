import maskImg from "./assets/mask.png";
import { id } from "./selectors";
id("mask-img").src = maskImg;
