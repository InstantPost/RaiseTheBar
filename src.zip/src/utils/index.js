import { urlify } from "./urlify";
import { boldText } from "./TextProcessing";
const utils = {
  urlify,
  boldText,
};

export default utils;
