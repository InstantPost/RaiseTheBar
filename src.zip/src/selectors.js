export function id(str) {
  return document.getElementById(str);
}
export function cls(str) {
  return document.getElementsByClassName(str);
}
